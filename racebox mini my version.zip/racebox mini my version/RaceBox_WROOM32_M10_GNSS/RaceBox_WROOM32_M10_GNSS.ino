#include <Wire.h>
#include <BMI160Gen.h>
#include <SparkFun_u-blox_GNSS_Arduino_Library.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <string>
#include <vector>

// --- u-blox M10 GNSS Configuration ---
// ESP32-WROOM32 wiring is kept unchanged:
// GNSS TX -> GPIO16 (ESP32 RX)
// GNSS RX -> GPIO17 (ESP32 TX)
#define GPS_RX_PIN 16
#define GPS_TX_PIN 17
#define GPS_BAUD 115200

// RUSHFPV u-blox M10 is normally 115200 baud.
// We do not try the old 9600 -> 115200 migration here.
#define MAX_NAVIGATION_RATE 25

SFE_UBLOX_GNSS myGNSS;
HardwareSerial GPS_Serial(2);

// For 25 Hz on u-blox M10 use one GNSS constellation.
// GPS ON, Galileo/GLONASS/BeiDou/QZSS/SBAS OFF.
// If multiple constellations are enabled, the M10 maximum rate drops.

constexpr const char* rawDeviceName = "RaceBox Mini 3897777152";

constexpr unsigned long MAX_ALLOWED = 3999999999;

constexpr unsigned long parseSuffix(const char* name) {
    unsigned long val = 0;
    for (int i = 13; i < 23; ++i) {
        val = val * 10 + (name[i] - '0');
    }
    return val;
}

static_assert(parseSuffix(rawDeviceName) <= MAX_ALLOWED, 
              "ERROR: RaceBox Mini number cannot exceed 3999999999 for compatibility with the official RaceBox App");

const String deviceName = rawDeviceName;

const int OnboardledPin = 2;

// --- BMI160 Configuration ---
const int BMI160_I2C_ADDR = 0x68;   // 0x68 если SA0=GND, 0x69 если SA0=3.3V
const unsigned long AccelSampleInterval = 10; // 10ms = 100Hz

// Smoothing
float accelAlpha = 0.8; 
float gyroAlpha = 0.8; 
float filtered_ax = 0, filtered_ay = 0, filtered_az = 0;
float filtered_gx = 0, filtered_gy = 0, filtered_gz = 0;

// --- BLE Configuration ---
const char* const RACEBOX_SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
const char* const RACEBOX_CHARACTERISTIC_RX_UUID = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E";
const char* const RACEBOX_CHARACTERISTIC_TX_UUID = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";

BLEServer *pServer = NULL;
BLECharacteristic *pCharacteristicTx = NULL;
BLECharacteristic *pCharacteristicRx = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;

// --- Packet Timing ---
unsigned long lastPacketSendTime = 0;
const unsigned long PACKET_SEND_INTERVAL_MS = 40;
unsigned long lastGpsRateCheckTime = 0;
unsigned int gpsUpdateCount = 0;
const unsigned long GPS_RATE_REPORT_INTERVAL_MS = 5000;
unsigned int gnssUpdateCount = 0;

// --- BLE Callbacks ---
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *pServer) {
    deviceConnected = true;
    pServer->updatePeerMTU(pServer->getConnId(), 128); 
    digitalWrite(OnboardledPin, HIGH);
    Serial.println("✅ BLE Client connected & MTU update requested");
  }
  void onDisconnect(BLEServer *pServer) {
    deviceConnected = false;
    digitalWrite(OnboardledPin, LOW);
    Serial.println("❌ BLE Client disconnected");
  }
};

class MyCharacteristicCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String rxValue = pCharacteristic->getValue(); 
    
    if (rxValue.length() > 0) {
      Serial.print("📨 Received BLE command: ");
      for (size_t i = 0; i < rxValue.length(); i++) {
        Serial.printf("0x%02X ", (uint8_t)rxValue[i]);
      }
      Serial.println();
    }
  }
};

// --- UBX Packet Construction Helpers ---
void writeLittleEndian(uint8_t* buffer, int offset, uint32_t value) { memcpy(buffer + offset, &value, 4); }
void writeLittleEndian(uint8_t* buffer, int offset, int32_t value)  { memcpy(buffer + offset, &value, 4); }
void writeLittleEndian(uint8_t* buffer, int offset, uint16_t value) { memcpy(buffer + offset, &value, 2); }
void writeLittleEndian(uint8_t* buffer, int offset, int16_t value)  { memcpy(buffer + offset, &value, 2); }
void writeLittleEndian(uint8_t* buffer, int offset, uint8_t value)  { buffer[offset] = value; }
void writeLittleEndian(uint8_t* buffer, int offset, int8_t value)   { buffer[offset] = (uint8_t)value; }

void calculateChecksum(uint8_t* payload, uint16_t len, uint8_t cls, uint8_t id, uint8_t* ckA, uint8_t* ckB) {
  *ckA = *ckB = 0;
  *ckA += cls; *ckB += *ckA;
  *ckA += id; *ckB += *ckA;
  *ckA += len & 0xFF; *ckB += *ckA;
  *ckA += len >> 8; *ckB += *ckA;
  for (uint16_t i = 0; i < len; i++) {
    *ckA += payload[i];
    *ckB += *ckA;
  }
}

// --- u-blox M10 UBX-CFG-VALSET helpers ---
static void m10Checksum(const uint8_t *data, size_t len, uint8_t &ckA, uint8_t &ckB) {
  ckA = 0;
  ckB = 0;
  for (size_t i = 0; i < len; i++) {
    ckA += data[i];
    ckB += ckA;
  }
}

static void m10WriteU1(uint8_t *buf, size_t &pos, uint32_t key, uint8_t value) {
  memcpy(buf + pos, &key, 4); pos += 4;
  buf[pos++] = value;
}

static void m10WriteU2(uint8_t *buf, size_t &pos, uint32_t key, uint16_t value) {
  memcpy(buf + pos, &key, 4); pos += 4;
  memcpy(buf + pos, &value, 2); pos += 2;
}

// Send UBX-CFG-VALSET to the M10.
// Layer 0x03 = RAM + BBR. This avoids writing flash on every boot.
static bool m10SendValset(const uint8_t *values, size_t valuesLen) {
  // CFG-VALSET payload:
  // version(1), layers(1), reserved(2), then key/value pairs.
  const uint16_t payloadLen = 4 + valuesLen;
  uint8_t packet[128];
  if (payloadLen + 8 > sizeof(packet)) return false;

  packet[0] = 0xB5;
  packet[1] = 0x62;
  packet[2] = 0x06; // CFG
  packet[3] = 0x8A; // VALSET
  packet[4] = payloadLen & 0xFF;
  packet[5] = payloadLen >> 8;

  packet[6] = 0x00; // version
  packet[7] = 0x03; // RAM + BBR
  packet[8] = 0x00; // reserved
  packet[9] = 0x00; // reserved

  memcpy(packet + 10, values, valuesLen);

  uint8_t ckA, ckB;
  m10Checksum(packet + 2, 4 + payloadLen, ckA, ckB);
  packet[10 + valuesLen] = ckA;
  packet[11 + valuesLen] = ckB;

  GPS_Serial.write(packet, 12 + valuesLen);
  GPS_Serial.flush();
  delay(80);
  return true;
}

static bool configureM10For25Hz() {
  uint8_t values[100];
  size_t pos = 0;

  // Configuration keys:
 //0x1031001F = GPS signal enable
  //0x10310021 = Galileo signal enable
  // 0x10310022 = BeiDou signal enable
  // 0x10310024 = QZSS signal enable
  // 0x10310025 = GLONASS signal enable
  // 0x30210001 = measurement rate in ms (U2)
  // 0x30210002 = navigation rate (U2)
  // 0x20110021 = dynamic model (E1), 4 = automotive
  // 0x20910007 = UBX-NAV-PVT output on UART1 (U1)

  m10WriteU1(values, pos, 0x1031001F, 1); // GPS ON
  m10WriteU1(values, pos, 0x10310021, 1); // Galileo OFF
  m10WriteU1(values, pos, 0x10310022, 1); // BeiDou OFF
  m10WriteU1(values, pos, 0x10310024, 1); // QZSS OFF
  m10WriteU1(values, pos, 0x10310025, 1); // GLONASS OFF

  m10WriteU2(values, pos, 0x30210001, 40); // 40 ms = 25 Hz
  m10WriteU2(values, pos, 0x30210002, 1);  // navigation rate = 1

  m10WriteU1(values, pos, 0x20110021, 4);  // automotive

  // NAV-PVT at 25 Hz on UART1.
  // The SparkFun library parses this message in checkUblox()/getPVT().
  m10WriteU1(values, pos, 0x20910007, 1);

  return m10SendValset(values, pos);
}

static bool initM10() {
  GPS_Serial.begin(GPS_BAUD, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);
  delay(300);

  if (!myGNSS.begin(GPS_Serial)) {
    Serial.println("❌ u-blox M10 not detected at 115200 baud.");
    Serial.println("Check: GNSS TX -> GPIO16, GNSS RX -> GPIO17, GND common, power.");
    return false;
  }

  Serial.println("✅ u-blox M10 detected at 115200 baud.");

  if (configureM10For25Hz()) {
    Serial.println("✅ M10 configured: GPS ON, other constellations OFF, NAV-PVT 25 Hz.");
  } else {
    Serial.println("❌ Failed to send M10 CFG-VALSET.");
    return false;
  }

  delay(200);

  // Do not use the old enableGNSS() / setNavigationFrequency() configuration
  // here: the M10 uses the modern UBX-CFG-VALSET configuration interface.
  return true;
}


void setup() {
  Serial.begin(115200);
  pinMode(OnboardledPin, OUTPUT);

  // --- BMI160 Init ---
  Wire.begin();   // ESP32 default: SDA=21, SCL=22
  if (!BMI160.begin(BMI160GenClass::I2C_MODE, BMI160_I2C_ADDR)) {
    Serial.println("❌ Failed to find BMI160 chip");
    while (1) delay(100);
  }
  Serial.println("✅ BMI160 found");

  // Диапазоны как у MPU6050
  BMI160.setAccelerometerRange(8);   // ±8g
  BMI160.setGyroRange(500);          // ±500 °/s

  // Опционально: повысить частоту (если нужно)
  // BMI160.setAccelRate(BMI160_ACCEL_RATE_1600HZ);
  // BMI160.setGyroRate(BMI160_GYRO_RATE_1600HZ);

  // Инициализация фильтра первыми реальными значениями
  int axRaw, ayRaw, azRaw, gxRaw, gyRaw, gzRaw;
  BMI160.readAccelerometer(axRaw, ayRaw, azRaw);
  BMI160.readGyro(gxRaw, gyRaw, gzRaw);

  filtered_ax = (axRaw * 8.0f / 32768.0f) * 9.80665f;
  filtered_ay = (ayRaw * 8.0f / 32768.0f) * 9.80665f;
  filtered_az = (azRaw * 8.0f / 32768.0f) * 9.80665f;
  filtered_gx = (gxRaw * 500.0f / 32768.0f) * (M_PI / 180.0f);
  filtered_gy = (gyRaw * 500.0f / 32768.0f) * (M_PI / 180.0f);
  filtered_gz = (gzRaw * 500.0f / 32768.0f) * (M_PI / 180.0f);

  // --- GNSS ---
  if (!initM10()) {
    while (1) delay(100);
  }

  // NAV-PVT output was enabled directly with UBX-CFG-VALSET above.
  // getPVT()/checkUblox() are used only for parsing the incoming NAV-PVT data.

  // --- BLE Setup ---
  BLEDevice::init(deviceName.c_str());
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService *pService = pServer->createService(RACEBOX_SERVICE_UUID);
  pCharacteristicTx = pService->createCharacteristic(RACEBOX_CHARACTERISTIC_TX_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  pCharacteristicTx->addDescriptor(new BLE2902());
  pCharacteristicRx = pService->createCharacteristic(RACEBOX_CHARACTERISTIC_RX_UUID, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  pCharacteristicRx->setCallbacks(new MyCharacteristicCallbacks());
  pService->start();

  // Device Information Service
  BLEService *pDeviceInfo = pServer->createService("0000180a-0000-1000-8000-00805f9b34fb");
  BLECharacteristic *pModel = pDeviceInfo->createCharacteristic("00002a24-0000-1000-8000-00805f9b34fb", BLECharacteristic::PROPERTY_READ);
  pModel->setValue("RaceBox Mini");
  BLECharacteristic *pSerial = pDeviceInfo->createCharacteristic("00002a25-0000-1000-8000-00805f9b34fb", BLECharacteristic::PROPERTY_READ);
  if (deviceName.length() >= 10) {
      pSerial->setValue(deviceName.substring(deviceName.length() - 10));
  } else {
      pSerial->setValue("0000000000");
  }
  BLECharacteristic *pFirm = pDeviceInfo->createCharacteristic("00002a26-0000-1000-8000-00805f9b34fb", BLECharacteristic::PROPERTY_READ);
  pFirm->setValue("3.3");
  BLECharacteristic *pHardware = pDeviceInfo->createCharacteristic("00002a27-0000-1000-8000-00805f9b34fb", BLECharacteristic::PROPERTY_READ);
  pHardware->setValue("1");
  BLECharacteristic *pManufacturer = pDeviceInfo->createCharacteristic("00002a29-0000-1000-8000-00805f9b34fb", BLECharacteristic::PROPERTY_READ);
  pManufacturer->setValue("RaceBox");
  pDeviceInfo->start();

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(RACEBOX_SERVICE_UUID);
  pAdvertising->addServiceUUID("0000180a-0000-1000-8000-00805f9b34fb");
  pAdvertising->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("📡 BLE advertising started.");

  lastGpsRateCheckTime = millis();
}

void loop() {
  myGNSS.checkUblox();

  static unsigned long lastAccelReadMs = 0;
  if (millis() - lastAccelReadMs >= AccelSampleInterval) {
    lastAccelReadMs = millis();

    int axRaw, ayRaw, azRaw, gxRaw, gyRaw, gzRaw;
    BMI160.readAccelerometer(axRaw, ayRaw, azRaw);
    BMI160.readGyro(gxRaw, gyRaw, gzRaw);

    // Конвертация в физические единицы (±8g и ±500 °/s)
    float ax = (axRaw * 8.0f / 32768.0f) * 9.80665f;   // m/s²
    float ay = (ayRaw * 8.0f / 32768.0f) * 9.80665f;
    float az = (azRaw * 8.0f / 32768.0f) * 9.80665f;

    float gx = (gxRaw * 500.0f / 32768.0f) * (M_PI / 180.0f); // rad/s
    float gy = (gyRaw * 500.0f / 32768.0f) * (M_PI / 180.0f);
    float gz = (gzRaw * 500.0f / 32768.0f) * (M_PI / 180.0f);

    // EMA filter
    filtered_ax = (accelAlpha * ax) + ((1.0f - accelAlpha) * filtered_ax);
    filtered_ay = (accelAlpha * ay) + ((1.0f - accelAlpha) * filtered_ay);
    filtered_az = (accelAlpha * az) + ((1.0f - accelAlpha) * filtered_az);

    filtered_gx = (gyroAlpha * gx) + ((1.0f - gyroAlpha) * filtered_gx);
    filtered_gy = (gyroAlpha * gy) + ((1.0f - gyroAlpha) * filtered_gy);
    filtered_gz = (gyroAlpha * gz) + ((1.0f - gyroAlpha) * filtered_gz);
  }

  // LED Blink
  if (!deviceConnected) {
    static unsigned long lastBlinkMs = 0;
    if (millis() - lastBlinkMs > 500) {
      lastBlinkMs = millis();
      digitalWrite(OnboardledPin, !digitalRead(OnboardledPin));
    }
  } else {
    digitalWrite(OnboardledPin, HIGH);
  }

  if (myGNSS.getPVT() && myGNSS.packetUBXNAVPVT != NULL) {
    static uint32_t lastITOW = 0;
    uint32_t currentITOW = myGNSS.packetUBXNAVPVT->data.iTOW;

    if (currentITOW != lastITOW) {
      lastITOW = currentITOW;
      gnssUpdateCount++;

      if (deviceConnected && myGNSS.packetUBXNAVPVT != NULL) {
        const unsigned long now = millis();
        lastPacketSendTime = now;
        gpsUpdateCount++;

        // milli-g
        int16_t gX = filtered_ax * 1000.0f / 9.80665f;
        int16_t gY = filtered_ay * 1000.0f / 9.80665f;
        int16_t gZ = filtered_az * 1000.0f / 9.80665f;

        // centi-deg/s
        int16_t rX = filtered_gx * 180.0f / M_PI * 100.0f;
        int16_t rY = filtered_gy * 180.0f / M_PI * 100.0f;
        int16_t rZ = filtered_gz * 180.0f / M_PI * 100.0f;

        uint8_t payload[80] = {0};
        uint8_t packet[88] = {0};

        writeLittleEndian(payload, 0, myGNSS.packetUBXNAVPVT->data.iTOW);
        writeLittleEndian(payload, 4, myGNSS.packetUBXNAVPVT->data.year);
        writeLittleEndian(payload, 6, myGNSS.packetUBXNAVPVT->data.month);
        writeLittleEndian(payload, 7, myGNSS.packetUBXNAVPVT->data.day);
        writeLittleEndian(payload, 8, myGNSS.packetUBXNAVPVT->data.hour);
        writeLittleEndian(payload, 9, myGNSS.packetUBXNAVPVT->data.min);
        writeLittleEndian(payload, 10, myGNSS.packetUBXNAVPVT->data.sec);

        uint8_t raceboxValidityFlags = 0;
        if (myGNSS.packetUBXNAVPVT->data.valid.bits.validDate) raceboxValidityFlags |= (1 << 0);
        if (myGNSS.packetUBXNAVPVT->data.valid.bits.validTime) raceboxValidityFlags |= (1 << 1);
        if (myGNSS.packetUBXNAVPVT->data.valid.bits.fullyResolved) raceboxValidityFlags |= (1 << 2);
        writeLittleEndian(payload, 11, raceboxValidityFlags);

        writeLittleEndian(payload, 12, myGNSS.packetUBXNAVPVT->data.tAcc);
        writeLittleEndian(payload, 16, myGNSS.packetUBXNAVPVT->data.nano);
        writeLittleEndian(payload, 20, myGNSS.packetUBXNAVPVT->data.fixType);

        uint8_t fixStatusFlagsRacebox = 0;
        if (myGNSS.packetUBXNAVPVT->data.fixType == 3) {
            fixStatusFlagsRacebox |= (1 << 0);
        }
        if (myGNSS.getHeadVehValid()) {
            fixStatusFlagsRacebox |= (1 << 5);
        }
        writeLittleEndian(payload, 21, fixStatusFlagsRacebox);

        uint8_t raceboxDateTimeFlags = 0;
        if (myGNSS.packetUBXNAVPVT->data.valid.bits.validTime) raceboxDateTimeFlags |= (1 << 5);
        if (myGNSS.packetUBXNAVPVT->data.valid.bits.validDate) raceboxDateTimeFlags |= (1 << 6);
        if (myGNSS.packetUBXNAVPVT->data.valid.bits.validTime && myGNSS.packetUBXNAVPVT->data.valid.bits.fullyResolved) raceboxDateTimeFlags |= (1 << 7);
        writeLittleEndian(payload, 22, raceboxDateTimeFlags);

        writeLittleEndian(payload, 23, myGNSS.packetUBXNAVPVT->data.numSV);
        writeLittleEndian(payload, 24, myGNSS.packetUBXNAVPVT->data.lon);
        writeLittleEndian(payload, 28, myGNSS.packetUBXNAVPVT->data.lat);
        writeLittleEndian(payload, 32, myGNSS.packetUBXNAVPVT->data.height);
        writeLittleEndian(payload, 36, myGNSS.packetUBXNAVPVT->data.hMSL);
        writeLittleEndian(payload, 40, myGNSS.packetUBXNAVPVT->data.hAcc);
        writeLittleEndian(payload, 44, myGNSS.packetUBXNAVPVT->data.vAcc);
        writeLittleEndian(payload, 48, myGNSS.packetUBXNAVPVT->data.gSpeed);
        writeLittleEndian(payload, 52, myGNSS.packetUBXNAVPVT->data.headMot);
        writeLittleEndian(payload, 56, myGNSS.packetUBXNAVPVT->data.sAcc);
        writeLittleEndian(payload, 60, myGNSS.packetUBXNAVPVT->data.headAcc);
        writeLittleEndian(payload, 64, myGNSS.packetUBXNAVPVT->data.pDOP);

        uint8_t latLonFlags = 0;
        if (myGNSS.packetUBXNAVPVT->data.fixType < 2) {
            latLonFlags |= (1 << 0);
        }
        writeLittleEndian(payload, 66, latLonFlags);
        writeLittleEndian(payload, 67, (uint8_t)100);   // battery 100%

        writeLittleEndian(payload, 68, gX);
        writeLittleEndian(payload, 70, gY);
        writeLittleEndian(payload, 72, gZ);
        writeLittleEndian(payload, 74, rX);
        writeLittleEndian(payload, 76, rY);
        writeLittleEndian(payload, 78, rZ);

        // UBX wrapper
        packet[0] = 0xB5;
        packet[1] = 0x62;
        packet[2] = 0xFF;
        packet[3] = 0x01;
        packet[4] = 80;
        packet[5] = 0;
        memcpy(packet + 6, payload, 80);
        uint8_t ckA, ckB; 
        calculateChecksum(payload, 80, 0xFF, 0x01, &ckA, &ckB);
        packet[86] = ckA;
        packet[87] = ckB;

        pCharacteristicTx->setValue(packet, 88);
        pCharacteristicTx->notify();
        delay(5);
      }
    }

    // Rate report
    const unsigned long now = millis();
    if ((now - lastGpsRateCheckTime) >= GPS_RATE_REPORT_INTERVAL_MS) {
      float bleRate = gpsUpdateCount / (GPS_RATE_REPORT_INTERVAL_MS / 1000.0);
      float gnssRate = gnssUpdateCount / (GPS_RATE_REPORT_INTERVAL_MS / 1000.0);
      uint8_t sats = 0;
      uint8_t fix = 0;
      uint32_t hAcc = 0;
      double lat = 0.0, lon = 0.0;
      if (myGNSS.packetUBXNAVPVT != NULL) {
        sats = myGNSS.packetUBXNAVPVT->data.numSV;
        fix = myGNSS.packetUBXNAVPVT->data.fixType;
        hAcc = myGNSS.packetUBXNAVPVT->data.hAcc;
        lat = myGNSS.packetUBXNAVPVT->data.lat * 1e-7;
        lon = myGNSS.packetUBXNAVPVT->data.lon * 1e-7;
      }
      Serial.printf("BLE Packet Rate: %.2f Hz | GNSS Update Rate: %.2f Hz | SVs: %u | Fix: %u | HAcc: %u mm | Lat: %.7f Lon: %.7f\n",
                    bleRate, gnssRate, sats, fix, hAcc, lat, lon);
      gpsUpdateCount = 0;
      gnssUpdateCount = 0;
      lastGpsRateCheckTime = now;
    }

    if (!deviceConnected && oldDeviceConnected) {
      delay(500);
      pServer->startAdvertising();
      oldDeviceConnected = deviceConnected;
    }
    if (deviceConnected && !oldDeviceConnected) {
      oldDeviceConnected = deviceConnected;
    }
  }
}